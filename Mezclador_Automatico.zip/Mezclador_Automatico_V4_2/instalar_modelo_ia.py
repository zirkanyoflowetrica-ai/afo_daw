"""Descarga manual voluntaria del modelo de reconocimiento CLAP (~varios cientos MB)."""
from ai_classifier import MODEL_ID

if __name__ == '__main__':
    from transformers import ClapModel, ClapProcessor
    print('Descargando modelo de identificacion de instrumentos desde Hugging Face...')
    ClapProcessor.from_pretrained(MODEL_ID)
    ClapModel.from_pretrained(MODEL_ID)
    print('Modelo guardado en cache local. Ya puedes iniciar el mezclador.')
