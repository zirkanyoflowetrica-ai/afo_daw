@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Ejecuta primero iniciar_windows.bat para crear el entorno.
  pause
  exit /b 1
)
echo AVISO: los pesos del modelo DrumSep tienen licencia comercial sin aclarar.
echo Utilizalo solo para pruebas NO comerciales hasta verificar los derechos.
choice /M "Quieres instalar el separador neuronal experimental"
if errorlevel 2 exit /b 0
where git >nul 2>nul
if errorlevel 1 (echo Instala Git para Windows primero. & pause & exit /b 1)
echo Instalando MDXNet-infer (tercero), requiere internet y espacio en disco.
".venv\Scripts\python.exe" -m pip install "mdxnet-infer @ git+https://github.com/openmirlab/mdxnet-infer.git"
if errorlevel 1 (echo Fallo la instalacion. & pause & exit /b 1)
".venv\Scripts\python.exe" -c "from mdxnet_infer import MDX23CInference; MDX23CInference.from_pretrained('drumsep-6stem')"
if errorlevel 1 (echo Fallo la descarga del modelo. & pause & exit /b 1)
echo enabled>".modelo_drumsep_activado"
echo Instalado y activado. Para desactivarlo borra .modelo_drumsep_activado
pause
