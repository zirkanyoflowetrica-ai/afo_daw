@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Primero ejecuta iniciar_windows.bat para preparar el entorno.
 pause
 exit /b 1
)
echo Instalando Beat This! (usa PyTorch y puede descargar modelos grandes)...
".venv\Scripts\python.exe" -m pip install beat-this
if errorlevel 1 (
 echo No se pudo instalar Beat This. El mezclador sigue funcionando con Librosa.
 pause
 exit /b 1
)
echo Instalado. En el primer analisis con Beat This habilitado puede descargarse su checkpoint.
pause
