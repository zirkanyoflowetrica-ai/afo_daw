@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Ejecuta primero iniciar_windows.bat para instalar la base.
  pause
  exit /b 1
)
echo Instalando PyTorch y Transformers; puede ocupar varios GB.
".venv\Scripts\python.exe" -m pip install -r requirements_ia_opcional.txt
if errorlevel 1 (echo Error instalando dependencias. & pause & exit /b 1)
".venv\Scripts\python.exe" instalar_modelo_ia.py
if errorlevel 1 (echo Error descargando el modelo. & pause & exit /b 1)
echo Listo: la IA local se activara automaticamente.
pause
