@echo off
setlocal
cd /d "%~dp0"
echo Essentia no ofrece Python nativo Windows. Se instalara SOLO dentro de WSL.
where wsl.exe >nul 2>nul
if errorlevel 1 (
 echo WSL no esta disponible. Abre la documentacion CAMBIOS_V4_1.txt.
 pause
 exit /b 1
)
wsl.exe -e bash -lc "python3 -m venv \"$HOME/.venvs/mezclador-essentia\" && \"$HOME/.venvs/mezclador-essentia/bin/python\" -m pip install essentia"
if errorlevel 1 (
 echo Instalacion WSL no completada. En Ubuntu tal vez necesites python3-venv.
 echo Ejecuta desde Ubuntu: sudo apt install python3-venv
 pause
 exit /b 1
)
echo Essentia instalado para el analisis hibrido a traves de WSL.
pause
