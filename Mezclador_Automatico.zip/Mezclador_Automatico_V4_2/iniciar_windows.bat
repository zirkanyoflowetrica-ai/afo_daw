@echo off
setlocal
cd /d "%~dp0"
if not exist "temporales" mkdir "temporales"
if not exist "logs" mkdir "logs"
set "TEMP=%~dp0temporales"
set "TMP=%~dp0temporales"
set "GRADIO_TEMP_DIR=%~dp0cache_gradio"
set "PIP_CACHE_DIR=%~dp0cache_pip"
set "PIP_DISABLE_PIP_VERSION_CHECK=1"
set "PYTHON=python"
where py >nul 2>nul
if not errorlevel 1 (
    py -3.12 -c "import sys" >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON=py -3.12"
    ) else (
        py -3.11 -c "import sys" >nul 2>nul
        if not errorlevel 1 (
            set "PYTHON=py -3.11"
        ) else (
            py -3.10 -c "import sys" >nul 2>nul
            if not errorlevel 1 set "PYTHON=py -3.10"
        )
    )
)
if not exist ".venv\Scripts\python.exe" (
    echo Creando entorno virtual Python...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto :fail
)
echo Instalando/verificando dependencias...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail
echo Abriendo mezclador automatico...
echo El registro se guarda en logs\consola.log
".venv\Scripts\python.exe" -u app.py >> "logs\consola.log" 2>&1
if errorlevel 1 goto :fail
exit /b 0
:fail
echo.
echo Hubo un error al iniciar. Revisa logs\consola.log y logs\errores.log.
pause
exit /b 1
